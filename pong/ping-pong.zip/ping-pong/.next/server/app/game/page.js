/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "app/game/page";
exports.ids = ["app/game/page"];
exports.modules = {

/***/ "../../client/components/action-async-storage.external":
/*!*******************************************************************************!*\
  !*** external "next/dist/client/components/action-async-storage.external.js" ***!
  \*******************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/client/components/action-async-storage.external.js");

/***/ }),

/***/ "./request-async-storage.external":
/*!*****************************************************************************!*\
  !*** external "next/dist/client/components/request-async-storage.external" ***!
  \*****************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/client/components/request-async-storage.external");

/***/ }),

/***/ "../../client/components/request-async-storage.external":
/*!********************************************************************************!*\
  !*** external "next/dist/client/components/request-async-storage.external.js" ***!
  \********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/client/components/request-async-storage.external.js");

/***/ }),

/***/ "./static-generation-async-storage.external":
/*!***************************************************************************************!*\
  !*** external "next/dist/client/components/static-generation-async-storage.external" ***!
  \***************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/client/components/static-generation-async-storage.external");

/***/ }),

/***/ "../../client/components/static-generation-async-storage.external":
/*!******************************************************************************************!*\
  !*** external "next/dist/client/components/static-generation-async-storage.external.js" ***!
  \******************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/client/components/static-generation-async-storage.external.js");

/***/ }),

/***/ "next/dist/compiled/next-server/app-page.runtime.dev.js":
/*!*************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-page.runtime.dev.js" ***!
  \*************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.dev.js");

/***/ }),

/***/ "child_process":
/*!********************************!*\
  !*** external "child_process" ***!
  \********************************/
/***/ ((module) => {

"use strict";
module.exports = require("child_process");

/***/ }),

/***/ "crypto":
/*!*************************!*\
  !*** external "crypto" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ "events":
/*!*************************!*\
  !*** external "events" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ "http":
/*!***********************!*\
  !*** external "http" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ "https":
/*!************************!*\
  !*** external "https" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ "net":
/*!**********************!*\
  !*** external "net" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ "os":
/*!*********************!*\
  !*** external "os" ***!
  \*********************/
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ "tls":
/*!**********************!*\
  !*** external "tls" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("tls");

/***/ }),

/***/ "tty":
/*!**********************!*\
  !*** external "tty" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ "url":
/*!**********************!*\
  !*** external "url" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ "?32c4":
/*!****************************!*\
  !*** bufferutil (ignored) ***!
  \****************************/
/***/ (() => {

/* (ignored) */

/***/ }),

/***/ "?66e9":
/*!********************************!*\
  !*** utf-8-validate (ignored) ***!
  \********************************/
/***/ (() => {

/* (ignored) */

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fgame%2Fpage&page=%2Fgame%2Fpage&appPaths=%2Fgame%2Fpage&pagePath=private-next-app-dir%2Fgame%2Fpage.tsx&appDir=%2Fhome%2Fmhanda%2FOnline-PoNg-Game%2Fping-pong%2Fsrc%2Fapp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=%2Fhome%2Fmhanda%2FOnline-PoNg-Game%2Fping-pong&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fgame%2Fpage&page=%2Fgame%2Fpage&appPaths=%2Fgame%2Fpage&pagePath=private-next-app-dir%2Fgame%2Fpage.tsx&appDir=%2Fhome%2Fmhanda%2FOnline-PoNg-Game%2Fping-pong%2Fsrc%2Fapp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=%2Fhome%2Fmhanda%2FOnline-PoNg-Game%2Fping-pong&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D! ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),\n/* harmony export */   __next_app__: () => (/* binding */ __next_app__),\n/* harmony export */   originalPathname: () => (/* binding */ originalPathname),\n/* harmony export */   pages: () => (/* binding */ pages),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   tree: () => (/* binding */ tree)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_future_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/future/route-modules/app-page/module.compiled */ \"(ssr)/./node_modules/next/dist/server/future/route-modules/app-page/module.compiled.js?5bc9\");\n/* harmony import */ var next_dist_server_future_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/future/route-kind */ \"(rsc)/./node_modules/next/dist/server/future/route-kind.js\");\n/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/client/components/error-boundary */ \"(rsc)/./node_modules/next/dist/client/components/error-boundary.js\");\n/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/dist/server/app-render/entry-base */ \"(rsc)/./node_modules/next/dist/server/app-render/entry-base.js\");\n/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};\n/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if([\"default\",\"tree\",\"pages\",\"GlobalError\",\"originalPathname\",\"__next_app__\",\"routeModule\"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]\n/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);\n\"TURBOPACK { transition: next-ssr }\";\n\n\n// We inject the tree and pages here so that we can use them in the route\n// module.\nconst tree = {\n        children: [\n        '',\n        {\n        children: [\n        'game',\n        {\n        children: ['__PAGE__', {}, {\n          page: [() => Promise.resolve(/*! import() eager */).then(__webpack_require__.bind(__webpack_require__, /*! ./src/app/game/page.tsx */ \"(rsc)/./src/app/game/page.tsx\")), \"/home/mhanda/Online-PoNg-Game/ping-pong/src/app/game/page.tsx\"],\n          \n        }]\n      },\n        {\n        \n        metadata: {\n    icon: [(async (props) => (await Promise.resolve(/*! import() eager */).then(__webpack_require__.bind(__webpack_require__, /*! next-metadata-image-loader?type=favicon&segment=&basePath=&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js!./src/app/favicon.ico?__next_metadata__ */ \"(rsc)/./node_modules/next/dist/build/webpack/loaders/next-metadata-image-loader.js?type=favicon&segment=&basePath=&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js!./src/app/favicon.ico?__next_metadata__\"))).default(props))],\n    apple: [],\n    openGraph: [],\n    twitter: [],\n    manifest: undefined\n  }\n      }\n      ]\n      },\n        {\n        'layout': [() => Promise.resolve(/*! import() eager */).then(__webpack_require__.bind(__webpack_require__, /*! ./src/app/layout.tsx */ \"(rsc)/./src/app/layout.tsx\")), \"/home/mhanda/Online-PoNg-Game/ping-pong/src/app/layout.tsx\"],\n'not-found': [() => Promise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! next/dist/client/components/not-found-error */ \"(rsc)/./node_modules/next/dist/client/components/not-found-error.js\", 23)), \"next/dist/client/components/not-found-error\"],\n        metadata: {\n    icon: [(async (props) => (await Promise.resolve(/*! import() eager */).then(__webpack_require__.bind(__webpack_require__, /*! next-metadata-image-loader?type=favicon&segment=&basePath=&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js!./src/app/favicon.ico?__next_metadata__ */ \"(rsc)/./node_modules/next/dist/build/webpack/loaders/next-metadata-image-loader.js?type=favicon&segment=&basePath=&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js!./src/app/favicon.ico?__next_metadata__\"))).default(props))],\n    apple: [],\n    openGraph: [],\n    twitter: [],\n    manifest: undefined\n  }\n      }\n      ]\n      }.children;\nconst pages = [\"/home/mhanda/Online-PoNg-Game/ping-pong/src/app/game/page.tsx\"];\n\n\nconst __next_app_require__ = __webpack_require__\nconst __next_app_load_chunk__ = () => Promise.resolve()\nconst originalPathname = \"/game/page\";\nconst __next_app__ = {\n    require: __next_app_require__,\n    loadChunk: __next_app_load_chunk__\n};\n\n// Create and export the route module that will be consumed.\nconst routeModule = new next_dist_server_future_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule({\n    definition: {\n        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,\n        page: \"/game/page\",\n        pathname: \"/game\",\n        // The following aren't used in production.\n        bundlePath: \"\",\n        filename: \"\",\n        appPaths: []\n    },\n    userland: {\n        loaderTree: tree\n    }\n});\n\n//# sourceMappingURL=app-page.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWFwcC1sb2FkZXIuanM/bmFtZT1hcHAlMkZnYW1lJTJGcGFnZSZwYWdlPSUyRmdhbWUlMkZwYWdlJmFwcFBhdGhzPSUyRmdhbWUlMkZwYWdlJnBhZ2VQYXRoPXByaXZhdGUtbmV4dC1hcHAtZGlyJTJGZ2FtZSUyRnBhZ2UudHN4JmFwcERpcj0lMkZob21lJTJGbWhhbmRhJTJGT25saW5lLVBvTmctR2FtZSUyRnBpbmctcG9uZyUyRnNyYyUyRmFwcCZwYWdlRXh0ZW5zaW9ucz10c3gmcGFnZUV4dGVuc2lvbnM9dHMmcGFnZUV4dGVuc2lvbnM9anN4JnBhZ2VFeHRlbnNpb25zPWpzJnJvb3REaXI9JTJGaG9tZSUyRm1oYW5kYSUyRk9ubGluZS1Qb05nLUdhbWUlMkZwaW5nLXBvbmcmaXNEZXY9dHJ1ZSZ0c2NvbmZpZ1BhdGg9dHNjb25maWcuanNvbiZiYXNlUGF0aD0mYXNzZXRQcmVmaXg9Jm5leHRDb25maWdPdXRwdXQ9JnByZWZlcnJlZFJlZ2lvbj0mbWlkZGxld2FyZUNvbmZpZz1lMzAlM0QhIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxhQUFhLHNCQUFzQjtBQUNpRTtBQUNyQztBQUMvRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQ0FBaUM7QUFDakMsdUJBQXVCLDBKQUFrRztBQUN6SDtBQUNBLFNBQVM7QUFDVCxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0Esb0NBQW9DLHNmQUF1UDtBQUMzUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBLHlCQUF5QixvSkFBK0Y7QUFDeEgsb0JBQW9CLDBOQUFnRjtBQUNwRztBQUNBLG9DQUFvQyxzZkFBdVA7QUFDM1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDdUI7QUFDNkQ7QUFDcEYsNkJBQTZCLG1CQUFtQjtBQUNoRDtBQUNPO0FBQ0E7QUFDUDtBQUNBO0FBQ0E7QUFDdUQ7QUFDdkQ7QUFDTyx3QkFBd0IsOEdBQWtCO0FBQ2pEO0FBQ0EsY0FBYyx5RUFBUztBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7QUFFRCIsInNvdXJjZXMiOlsid2VicGFjazovL3BpbmctcG9uZy8/MWY3MSJdLCJzb3VyY2VzQ29udGVudCI6WyJcIlRVUkJPUEFDSyB7IHRyYW5zaXRpb246IG5leHQtc3NyIH1cIjtcbmltcG9ydCB7IEFwcFBhZ2VSb3V0ZU1vZHVsZSB9IGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL2Z1dHVyZS9yb3V0ZS1tb2R1bGVzL2FwcC1wYWdlL21vZHVsZS5jb21waWxlZFwiO1xuaW1wb3J0IHsgUm91dGVLaW5kIH0gZnJvbSBcIm5leHQvZGlzdC9zZXJ2ZXIvZnV0dXJlL3JvdXRlLWtpbmRcIjtcbi8vIFdlIGluamVjdCB0aGUgdHJlZSBhbmQgcGFnZXMgaGVyZSBzbyB0aGF0IHdlIGNhbiB1c2UgdGhlbSBpbiB0aGUgcm91dGVcbi8vIG1vZHVsZS5cbmNvbnN0IHRyZWUgPSB7XG4gICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICcnLFxuICAgICAgICB7XG4gICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICdnYW1lJyxcbiAgICAgICAge1xuICAgICAgICBjaGlsZHJlbjogWydfX1BBR0VfXycsIHt9LCB7XG4gICAgICAgICAgcGFnZTogWygpID0+IGltcG9ydCgvKiB3ZWJwYWNrTW9kZTogXCJlYWdlclwiICovIFwiL2hvbWUvbWhhbmRhL09ubGluZS1Qb05nLUdhbWUvcGluZy1wb25nL3NyYy9hcHAvZ2FtZS9wYWdlLnRzeFwiKSwgXCIvaG9tZS9taGFuZGEvT25saW5lLVBvTmctR2FtZS9waW5nLXBvbmcvc3JjL2FwcC9nYW1lL3BhZ2UudHN4XCJdLFxuICAgICAgICAgIFxuICAgICAgICB9XVxuICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICBcbiAgICAgICAgbWV0YWRhdGE6IHtcbiAgICBpY29uOiBbKGFzeW5jIChwcm9wcykgPT4gKGF3YWl0IGltcG9ydCgvKiB3ZWJwYWNrTW9kZTogXCJlYWdlclwiICovIFwibmV4dC1tZXRhZGF0YS1pbWFnZS1sb2FkZXI/dHlwZT1mYXZpY29uJnNlZ21lbnQ9JmJhc2VQYXRoPSZwYWdlRXh0ZW5zaW9ucz10c3gmcGFnZUV4dGVuc2lvbnM9dHMmcGFnZUV4dGVuc2lvbnM9anN4JnBhZ2VFeHRlbnNpb25zPWpzIS9ob21lL21oYW5kYS9PbmxpbmUtUG9OZy1HYW1lL3BpbmctcG9uZy9zcmMvYXBwL2Zhdmljb24uaWNvP19fbmV4dF9tZXRhZGF0YV9fXCIpKS5kZWZhdWx0KHByb3BzKSldLFxuICAgIGFwcGxlOiBbXSxcbiAgICBvcGVuR3JhcGg6IFtdLFxuICAgIHR3aXR0ZXI6IFtdLFxuICAgIG1hbmlmZXN0OiB1bmRlZmluZWRcbiAgfVxuICAgICAgfVxuICAgICAgXVxuICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAnbGF5b3V0JzogWygpID0+IGltcG9ydCgvKiB3ZWJwYWNrTW9kZTogXCJlYWdlclwiICovIFwiL2hvbWUvbWhhbmRhL09ubGluZS1Qb05nLUdhbWUvcGluZy1wb25nL3NyYy9hcHAvbGF5b3V0LnRzeFwiKSwgXCIvaG9tZS9taGFuZGEvT25saW5lLVBvTmctR2FtZS9waW5nLXBvbmcvc3JjL2FwcC9sYXlvdXQudHN4XCJdLFxuJ25vdC1mb3VuZCc6IFsoKSA9PiBpbXBvcnQoLyogd2VicGFja01vZGU6IFwiZWFnZXJcIiAqLyBcIm5leHQvZGlzdC9jbGllbnQvY29tcG9uZW50cy9ub3QtZm91bmQtZXJyb3JcIiksIFwibmV4dC9kaXN0L2NsaWVudC9jb21wb25lbnRzL25vdC1mb3VuZC1lcnJvclwiXSxcbiAgICAgICAgbWV0YWRhdGE6IHtcbiAgICBpY29uOiBbKGFzeW5jIChwcm9wcykgPT4gKGF3YWl0IGltcG9ydCgvKiB3ZWJwYWNrTW9kZTogXCJlYWdlclwiICovIFwibmV4dC1tZXRhZGF0YS1pbWFnZS1sb2FkZXI/dHlwZT1mYXZpY29uJnNlZ21lbnQ9JmJhc2VQYXRoPSZwYWdlRXh0ZW5zaW9ucz10c3gmcGFnZUV4dGVuc2lvbnM9dHMmcGFnZUV4dGVuc2lvbnM9anN4JnBhZ2VFeHRlbnNpb25zPWpzIS9ob21lL21oYW5kYS9PbmxpbmUtUG9OZy1HYW1lL3BpbmctcG9uZy9zcmMvYXBwL2Zhdmljb24uaWNvP19fbmV4dF9tZXRhZGF0YV9fXCIpKS5kZWZhdWx0KHByb3BzKSldLFxuICAgIGFwcGxlOiBbXSxcbiAgICBvcGVuR3JhcGg6IFtdLFxuICAgIHR3aXR0ZXI6IFtdLFxuICAgIG1hbmlmZXN0OiB1bmRlZmluZWRcbiAgfVxuICAgICAgfVxuICAgICAgXVxuICAgICAgfS5jaGlsZHJlbjtcbmNvbnN0IHBhZ2VzID0gW1wiL2hvbWUvbWhhbmRhL09ubGluZS1Qb05nLUdhbWUvcGluZy1wb25nL3NyYy9hcHAvZ2FtZS9wYWdlLnRzeFwiXTtcbmV4cG9ydCB7IHRyZWUsIHBhZ2VzIH07XG5leHBvcnQgeyBkZWZhdWx0IGFzIEdsb2JhbEVycm9yIH0gZnJvbSBcIm5leHQvZGlzdC9jbGllbnQvY29tcG9uZW50cy9lcnJvci1ib3VuZGFyeVwiO1xuY29uc3QgX19uZXh0X2FwcF9yZXF1aXJlX18gPSBfX3dlYnBhY2tfcmVxdWlyZV9fXG5jb25zdCBfX25leHRfYXBwX2xvYWRfY2h1bmtfXyA9ICgpID0+IFByb21pc2UucmVzb2x2ZSgpXG5leHBvcnQgY29uc3Qgb3JpZ2luYWxQYXRobmFtZSA9IFwiL2dhbWUvcGFnZVwiO1xuZXhwb3J0IGNvbnN0IF9fbmV4dF9hcHBfXyA9IHtcbiAgICByZXF1aXJlOiBfX25leHRfYXBwX3JlcXVpcmVfXyxcbiAgICBsb2FkQ2h1bms6IF9fbmV4dF9hcHBfbG9hZF9jaHVua19fXG59O1xuZXhwb3J0ICogZnJvbSBcIm5leHQvZGlzdC9zZXJ2ZXIvYXBwLXJlbmRlci9lbnRyeS1iYXNlXCI7XG4vLyBDcmVhdGUgYW5kIGV4cG9ydCB0aGUgcm91dGUgbW9kdWxlIHRoYXQgd2lsbCBiZSBjb25zdW1lZC5cbmV4cG9ydCBjb25zdCByb3V0ZU1vZHVsZSA9IG5ldyBBcHBQYWdlUm91dGVNb2R1bGUoe1xuICAgIGRlZmluaXRpb246IHtcbiAgICAgICAga2luZDogUm91dGVLaW5kLkFQUF9QQUdFLFxuICAgICAgICBwYWdlOiBcIi9nYW1lL3BhZ2VcIixcbiAgICAgICAgcGF0aG5hbWU6IFwiL2dhbWVcIixcbiAgICAgICAgLy8gVGhlIGZvbGxvd2luZyBhcmVuJ3QgdXNlZCBpbiBwcm9kdWN0aW9uLlxuICAgICAgICBidW5kbGVQYXRoOiBcIlwiLFxuICAgICAgICBmaWxlbmFtZTogXCJcIixcbiAgICAgICAgYXBwUGF0aHM6IFtdXG4gICAgfSxcbiAgICB1c2VybGFuZDoge1xuICAgICAgICBsb2FkZXJUcmVlOiB0cmVlXG4gICAgfVxufSk7XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWFwcC1wYWdlLmpzLm1hcCJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fgame%2Fpage&page=%2Fgame%2Fpage&appPaths=%2Fgame%2Fpage&pagePath=private-next-app-dir%2Fgame%2Fpage.tsx&appDir=%2Fhome%2Fmhanda%2FOnline-PoNg-Game%2Fping-pong%2Fsrc%2Fapp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=%2Fhome%2Fmhanda%2FOnline-PoNg-Game%2Fping-pong&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!\n");

/***/ }),

/***/ "(ssr)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=%2Fhome%2Fmhanda%2FOnline-PoNg-Game%2Fping-pong%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Fapp-router.js&modules=%2Fhome%2Fmhanda%2FOnline-PoNg-Game%2Fping-pong%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Ferror-boundary.js&modules=%2Fhome%2Fmhanda%2FOnline-PoNg-Game%2Fping-pong%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Flayout-router.js&modules=%2Fhome%2Fmhanda%2FOnline-PoNg-Game%2Fping-pong%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Fnot-found-boundary.js&modules=%2Fhome%2Fmhanda%2FOnline-PoNg-Game%2Fping-pong%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Frender-from-template-context.js&modules=%2Fhome%2Fmhanda%2FOnline-PoNg-Game%2Fping-pong%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Fstatic-generation-searchparams-bailout-provider.js&server=true!":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=%2Fhome%2Fmhanda%2FOnline-PoNg-Game%2Fping-pong%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Fapp-router.js&modules=%2Fhome%2Fmhanda%2FOnline-PoNg-Game%2Fping-pong%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Ferror-boundary.js&modules=%2Fhome%2Fmhanda%2FOnline-PoNg-Game%2Fping-pong%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Flayout-router.js&modules=%2Fhome%2Fmhanda%2FOnline-PoNg-Game%2Fping-pong%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Fnot-found-boundary.js&modules=%2Fhome%2Fmhanda%2FOnline-PoNg-Game%2Fping-pong%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Frender-from-template-context.js&modules=%2Fhome%2Fmhanda%2FOnline-PoNg-Game%2Fping-pong%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Fstatic-generation-searchparams-bailout-provider.js&server=true! ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

eval("Promise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! ./node_modules/next/dist/client/components/app-router.js */ \"(ssr)/./node_modules/next/dist/client/components/app-router.js\", 23));\nPromise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! ./node_modules/next/dist/client/components/error-boundary.js */ \"(ssr)/./node_modules/next/dist/client/components/error-boundary.js\", 23));\nPromise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! ./node_modules/next/dist/client/components/layout-router.js */ \"(ssr)/./node_modules/next/dist/client/components/layout-router.js\", 23));\nPromise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! ./node_modules/next/dist/client/components/not-found-boundary.js */ \"(ssr)/./node_modules/next/dist/client/components/not-found-boundary.js\", 23));\nPromise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! ./node_modules/next/dist/client/components/render-from-template-context.js */ \"(ssr)/./node_modules/next/dist/client/components/render-from-template-context.js\", 23));\nPromise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! ./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js */ \"(ssr)/./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js\", 23))//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHNzcikvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWZsaWdodC1jbGllbnQtZW50cnktbG9hZGVyLmpzP21vZHVsZXM9JTJGaG9tZSUyRm1oYW5kYSUyRk9ubGluZS1Qb05nLUdhbWUlMkZwaW5nLXBvbmclMkZub2RlX21vZHVsZXMlMkZuZXh0JTJGZGlzdCUyRmNsaWVudCUyRmNvbXBvbmVudHMlMkZhcHAtcm91dGVyLmpzJm1vZHVsZXM9JTJGaG9tZSUyRm1oYW5kYSUyRk9ubGluZS1Qb05nLUdhbWUlMkZwaW5nLXBvbmclMkZub2RlX21vZHVsZXMlMkZuZXh0JTJGZGlzdCUyRmNsaWVudCUyRmNvbXBvbmVudHMlMkZlcnJvci1ib3VuZGFyeS5qcyZtb2R1bGVzPSUyRmhvbWUlMkZtaGFuZGElMkZPbmxpbmUtUG9OZy1HYW1lJTJGcGluZy1wb25nJTJGbm9kZV9tb2R1bGVzJTJGbmV4dCUyRmRpc3QlMkZjbGllbnQlMkZjb21wb25lbnRzJTJGbGF5b3V0LXJvdXRlci5qcyZtb2R1bGVzPSUyRmhvbWUlMkZtaGFuZGElMkZPbmxpbmUtUG9OZy1HYW1lJTJGcGluZy1wb25nJTJGbm9kZV9tb2R1bGVzJTJGbmV4dCUyRmRpc3QlMkZjbGllbnQlMkZjb21wb25lbnRzJTJGbm90LWZvdW5kLWJvdW5kYXJ5LmpzJm1vZHVsZXM9JTJGaG9tZSUyRm1oYW5kYSUyRk9ubGluZS1Qb05nLUdhbWUlMkZwaW5nLXBvbmclMkZub2RlX21vZHVsZXMlMkZuZXh0JTJGZGlzdCUyRmNsaWVudCUyRmNvbXBvbmVudHMlMkZyZW5kZXItZnJvbS10ZW1wbGF0ZS1jb250ZXh0LmpzJm1vZHVsZXM9JTJGaG9tZSUyRm1oYW5kYSUyRk9ubGluZS1Qb05nLUdhbWUlMkZwaW5nLXBvbmclMkZub2RlX21vZHVsZXMlMkZuZXh0JTJGZGlzdCUyRmNsaWVudCUyRmNvbXBvbmVudHMlMkZzdGF0aWMtZ2VuZXJhdGlvbi1zZWFyY2hwYXJhbXMtYmFpbG91dC1wcm92aWRlci5qcyZzZXJ2ZXI9dHJ1ZSEiLCJtYXBwaW5ncyI6IkFBQUEsa09BQW1JO0FBQ25JLDBPQUF1STtBQUN2SSx3T0FBc0k7QUFDdEksa1BBQTJJO0FBQzNJLHNRQUFxSjtBQUNySiIsInNvdXJjZXMiOlsid2VicGFjazovL3BpbmctcG9uZy8/NjE0ZCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQoLyogd2VicGFja01vZGU6IFwiZWFnZXJcIiAqLyBcIi9ob21lL21oYW5kYS9PbmxpbmUtUG9OZy1HYW1lL3BpbmctcG9uZy9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2NsaWVudC9jb21wb25lbnRzL2FwcC1yb3V0ZXIuanNcIik7XG5pbXBvcnQoLyogd2VicGFja01vZGU6IFwiZWFnZXJcIiAqLyBcIi9ob21lL21oYW5kYS9PbmxpbmUtUG9OZy1HYW1lL3BpbmctcG9uZy9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2NsaWVudC9jb21wb25lbnRzL2Vycm9yLWJvdW5kYXJ5LmpzXCIpO1xuaW1wb3J0KC8qIHdlYnBhY2tNb2RlOiBcImVhZ2VyXCIgKi8gXCIvaG9tZS9taGFuZGEvT25saW5lLVBvTmctR2FtZS9waW5nLXBvbmcvbm9kZV9tb2R1bGVzL25leHQvZGlzdC9jbGllbnQvY29tcG9uZW50cy9sYXlvdXQtcm91dGVyLmpzXCIpO1xuaW1wb3J0KC8qIHdlYnBhY2tNb2RlOiBcImVhZ2VyXCIgKi8gXCIvaG9tZS9taGFuZGEvT25saW5lLVBvTmctR2FtZS9waW5nLXBvbmcvbm9kZV9tb2R1bGVzL25leHQvZGlzdC9jbGllbnQvY29tcG9uZW50cy9ub3QtZm91bmQtYm91bmRhcnkuanNcIik7XG5pbXBvcnQoLyogd2VicGFja01vZGU6IFwiZWFnZXJcIiAqLyBcIi9ob21lL21oYW5kYS9PbmxpbmUtUG9OZy1HYW1lL3BpbmctcG9uZy9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2NsaWVudC9jb21wb25lbnRzL3JlbmRlci1mcm9tLXRlbXBsYXRlLWNvbnRleHQuanNcIik7XG5pbXBvcnQoLyogd2VicGFja01vZGU6IFwiZWFnZXJcIiAqLyBcIi9ob21lL21oYW5kYS9PbmxpbmUtUG9OZy1HYW1lL3BpbmctcG9uZy9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2NsaWVudC9jb21wb25lbnRzL3N0YXRpYy1nZW5lcmF0aW9uLXNlYXJjaHBhcmFtcy1iYWlsb3V0LXByb3ZpZGVyLmpzXCIpIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(ssr)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=%2Fhome%2Fmhanda%2FOnline-PoNg-Game%2Fping-pong%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Fapp-router.js&modules=%2Fhome%2Fmhanda%2FOnline-PoNg-Game%2Fping-pong%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Ferror-boundary.js&modules=%2Fhome%2Fmhanda%2FOnline-PoNg-Game%2Fping-pong%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Flayout-router.js&modules=%2Fhome%2Fmhanda%2FOnline-PoNg-Game%2Fping-pong%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Fnot-found-boundary.js&modules=%2Fhome%2Fmhanda%2FOnline-PoNg-Game%2Fping-pong%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Frender-from-template-context.js&modules=%2Fhome%2Fmhanda%2FOnline-PoNg-Game%2Fping-pong%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Fstatic-generation-searchparams-bailout-provider.js&server=true!\n");

/***/ }),

/***/ "(ssr)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=%2Fhome%2Fmhanda%2FOnline-PoNg-Game%2Fping-pong%2Fnode_modules%2Fnext%2Ffont%2Fgoogle%2Ftarget.css%3F%7B%22path%22%3A%22src%2Fapp%2Flayout.tsx%22%2C%22import%22%3A%22Inter%22%2C%22arguments%22%3A%5B%7B%22subsets%22%3A%5B%22latin%22%5D%7D%5D%2C%22variableName%22%3A%22inter%22%7D&modules=%2Fhome%2Fmhanda%2FOnline-PoNg-Game%2Fping-pong%2Fsrc%2Fapp%2Fglobals.css&server=true!":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=%2Fhome%2Fmhanda%2FOnline-PoNg-Game%2Fping-pong%2Fnode_modules%2Fnext%2Ffont%2Fgoogle%2Ftarget.css%3F%7B%22path%22%3A%22src%2Fapp%2Flayout.tsx%22%2C%22import%22%3A%22Inter%22%2C%22arguments%22%3A%5B%7B%22subsets%22%3A%5B%22latin%22%5D%7D%5D%2C%22variableName%22%3A%22inter%22%7D&modules=%2Fhome%2Fmhanda%2FOnline-PoNg-Game%2Fping-pong%2Fsrc%2Fapp%2Fglobals.css&server=true! ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "(ssr)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=%2Fhome%2Fmhanda%2FOnline-PoNg-Game%2Fping-pong%2Fsrc%2Fapp%2Fgame%2Fpage.tsx&server=true!":
/*!********************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=%2Fhome%2Fmhanda%2FOnline-PoNg-Game%2Fping-pong%2Fsrc%2Fapp%2Fgame%2Fpage.tsx&server=true! ***!
  \********************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

eval("Promise.resolve(/*! import() eager */).then(__webpack_require__.bind(__webpack_require__, /*! ./src/app/game/page.tsx */ \"(ssr)/./src/app/game/page.tsx\"))//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHNzcikvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWZsaWdodC1jbGllbnQtZW50cnktbG9hZGVyLmpzP21vZHVsZXM9JTJGaG9tZSUyRm1oYW5kYSUyRk9ubGluZS1Qb05nLUdhbWUlMkZwaW5nLXBvbmclMkZzcmMlMkZhcHAlMkZnYW1lJTJGcGFnZS50c3gmc2VydmVyPXRydWUhIiwibWFwcGluZ3MiOiJBQUFBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vcGluZy1wb25nLz8zNmUxIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCgvKiB3ZWJwYWNrTW9kZTogXCJlYWdlclwiICovIFwiL2hvbWUvbWhhbmRhL09ubGluZS1Qb05nLUdhbWUvcGluZy1wb25nL3NyYy9hcHAvZ2FtZS9wYWdlLnRzeFwiKSJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(ssr)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=%2Fhome%2Fmhanda%2FOnline-PoNg-Game%2Fping-pong%2Fsrc%2Fapp%2Fgame%2Fpage.tsx&server=true!\n");

/***/ }),

/***/ "(ssr)/./src/app/game/Ball.tsx":
/*!*******************************!*\
  !*** ./src/app/game/Ball.tsx ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Ball)\n/* harmony export */ });\nclass Ball {\n    constructor(ballElem){\n        this.ballElem = ballElem;\n    }\n    set x(value) {\n        this.ballElem.style.setProperty(\"--x\", value);\n    }\n    set y(value) {\n        this.ballElem.style.setProperty(\"--y\", value);\n    }\n    update(isAdmin, AdminX, AdminY) {\n        if (isAdmin) {\n            this.x = AdminX;\n            this.y = AdminY;\n        } else {\n            this.x = 100 - AdminX;\n            this.y = AdminY;\n        }\n    }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHNzcikvLi9zcmMvYXBwL2dhbWUvQmFsbC50c3giLCJtYXBwaW5ncyI6Ijs7OztBQUFlLE1BQU1BO0lBQ25CQyxZQUFZQyxRQUE0QixDQUFFO1FBQ3hDLElBQUksQ0FBQ0EsUUFBUSxHQUFHQTtJQUNsQjtJQUVBLElBQUlDLEVBQUVDLEtBQWEsRUFBRTtRQUNuQixJQUFJLENBQUNGLFFBQVEsQ0FBQ0csS0FBSyxDQUFDQyxXQUFXLENBQUMsT0FBT0Y7SUFDekM7SUFDQSxJQUFJRyxFQUFFSCxLQUFhLEVBQUU7UUFDbkIsSUFBSSxDQUFDRixRQUFRLENBQUNHLEtBQUssQ0FBQ0MsV0FBVyxDQUFDLE9BQU9GO0lBQ3pDO0lBRUFJLE9BQU9DLE9BQWdCLEVBQUVDLE1BQWMsRUFBRUMsTUFBYyxFQUFFO1FBQ3ZELElBQUlGLFNBQVM7WUFDWCxJQUFJLENBQUNOLENBQUMsR0FBR087WUFDVCxJQUFJLENBQUNILENBQUMsR0FBR0k7UUFDWCxPQUFPO1lBQ0wsSUFBSSxDQUFDUixDQUFDLEdBQUcsTUFBTU87WUFDZixJQUFJLENBQUNILENBQUMsR0FBR0k7UUFDWDtJQUNGO0FBQ0YiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9waW5nLXBvbmcvLi9zcmMvYXBwL2dhbWUvQmFsbC50c3g/ZWEzYiJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZGVmYXVsdCBjbGFzcyBCYWxsIHtcbiAgY29uc3RydWN0b3IoYmFsbEVsZW06IEhUTUxFbGVtZW50IHwgbnVsbCkge1xuICAgIHRoaXMuYmFsbEVsZW0gPSBiYWxsRWxlbTtcbiAgfVxuXG4gIHNldCB4KHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLmJhbGxFbGVtLnN0eWxlLnNldFByb3BlcnR5KFwiLS14XCIsIHZhbHVlKTtcbiAgfVxuICBzZXQgeSh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5iYWxsRWxlbS5zdHlsZS5zZXRQcm9wZXJ0eShcIi0teVwiLCB2YWx1ZSk7XG4gIH1cbiAgXG4gIHVwZGF0ZShpc0FkbWluOiBib29sZWFuLCBBZG1pblg6IG51bWJlciwgQWRtaW5ZOiBudW1iZXIpIHtcbiAgICBpZiAoaXNBZG1pbikge1xuICAgICAgdGhpcy54ID0gQWRtaW5YO1xuICAgICAgdGhpcy55ID0gQWRtaW5ZO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLnggPSAxMDAgLSBBZG1pblg7XG4gICAgICB0aGlzLnkgPSBBZG1pblk7XG4gICAgfVxuICB9XG59XG4iXSwibmFtZXMiOlsiQmFsbCIsImNvbnN0cnVjdG9yIiwiYmFsbEVsZW0iLCJ4IiwidmFsdWUiLCJzdHlsZSIsInNldFByb3BlcnR5IiwieSIsInVwZGF0ZSIsImlzQWRtaW4iLCJBZG1pblgiLCJBZG1pblkiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(ssr)/./src/app/game/Ball.tsx\n");

/***/ }),

/***/ "(ssr)/./src/app/game/Paddle.tsx":
/*!*********************************!*\
  !*** ./src/app/game/Paddle.tsx ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   customStyles: () => (/* binding */ customStyles),\n/* harmony export */   \"default\": () => (/* binding */ Paddle)\n/* harmony export */ });\nclass Paddle {\n    constructor(paddleElem){\n        this.paddleElem = paddleElem;\n    }\n    get position() {\n        return parseFloat(getComputedStyle(this.paddleElem).getPropertyValue(\"--position\"));\n    }\n    set position(value) {\n        this.paddleElem.style.setProperty(\"--position\", value);\n    }\n    update(Player2Height) {\n        this.position = Player2Height;\n    }\n}\nconst customStyles = {\n    overlay: {\n        backgroundColor: \"rgba(3, 3, 3, 0.6)\"\n    },\n    content: {\n        top: \"50%\",\n        left: \"50%\",\n        right: \"auto\",\n        bottom: \"auto\",\n        marginRight: \"-50%\",\n        transform: \"translate(-50%, -50%)\"\n    }\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHNzcikvLi9zcmMvYXBwL2dhbWUvUGFkZGxlLnRzeCIsIm1hcHBpbmdzIjoiOzs7OztBQUFlLE1BQU1BO0lBQ25CQyxZQUFZQyxVQUE4QixDQUFFO1FBQzFDLElBQUksQ0FBQ0EsVUFBVSxHQUFHQTtJQUNwQjtJQUVBLElBQUlDLFdBQVc7UUFDYixPQUFPQyxXQUNMQyxpQkFBaUIsSUFBSSxDQUFDSCxVQUFVLEVBQUVJLGdCQUFnQixDQUFDO0lBRXZEO0lBQ0EsSUFBSUgsU0FBU0ksS0FBYSxFQUFFO1FBQzFCLElBQUksQ0FBQ0wsVUFBVSxDQUFDTSxLQUFLLENBQUNDLFdBQVcsQ0FBQyxjQUFjRjtJQUNsRDtJQUVBRyxPQUFPQyxhQUFxQixFQUFFO1FBQzVCLElBQUksQ0FBQ1IsUUFBUSxHQUFHUTtJQUNsQjtBQUNGO0FBRU8sTUFBTUMsZUFBZTtJQUMxQkMsU0FBUztRQUNQQyxpQkFBaUI7SUFDbkI7SUFDQUMsU0FBUztRQUNQQyxLQUFLO1FBQ0xDLE1BQU07UUFDTkMsT0FBTztRQUNQQyxRQUFRO1FBQ1JDLGFBQWE7UUFDYkMsV0FBVztJQUNiO0FBQ0YsRUFBRSIsInNvdXJjZXMiOlsid2VicGFjazovL3BpbmctcG9uZy8uL3NyYy9hcHAvZ2FtZS9QYWRkbGUudHN4P2U2NGUiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGRlZmF1bHQgY2xhc3MgUGFkZGxlIHtcbiAgY29uc3RydWN0b3IocGFkZGxlRWxlbTogSFRNTEVsZW1lbnQgfCBudWxsKSB7XG4gICAgdGhpcy5wYWRkbGVFbGVtID0gcGFkZGxlRWxlbTtcbiAgfVxuXG4gIGdldCBwb3NpdGlvbigpIHtcbiAgICByZXR1cm4gcGFyc2VGbG9hdChcbiAgICAgIGdldENvbXB1dGVkU3R5bGUodGhpcy5wYWRkbGVFbGVtKS5nZXRQcm9wZXJ0eVZhbHVlKFwiLS1wb3NpdGlvblwiKVxuICAgICk7XG4gIH1cbiAgc2V0IHBvc2l0aW9uKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLnBhZGRsZUVsZW0uc3R5bGUuc2V0UHJvcGVydHkoXCItLXBvc2l0aW9uXCIsIHZhbHVlKTtcbiAgfVxuXG4gIHVwZGF0ZShQbGF5ZXIySGVpZ2h0OiBudW1iZXIpIHtcbiAgICB0aGlzLnBvc2l0aW9uID0gUGxheWVyMkhlaWdodDtcbiAgfVxufVxuXG5leHBvcnQgY29uc3QgY3VzdG9tU3R5bGVzID0ge1xuICBvdmVybGF5OiB7XG4gICAgYmFja2dyb3VuZENvbG9yOiBcInJnYmEoMywgMywgMywgMC42KVwiLFxuICB9LFxuICBjb250ZW50OiB7XG4gICAgdG9wOiBcIjUwJVwiLFxuICAgIGxlZnQ6IFwiNTAlXCIsXG4gICAgcmlnaHQ6IFwiYXV0b1wiLFxuICAgIGJvdHRvbTogXCJhdXRvXCIsXG4gICAgbWFyZ2luUmlnaHQ6IFwiLTUwJVwiLFxuICAgIHRyYW5zZm9ybTogXCJ0cmFuc2xhdGUoLTUwJSwgLTUwJSlcIixcbiAgfSxcbn07XG4iXSwibmFtZXMiOlsiUGFkZGxlIiwiY29uc3RydWN0b3IiLCJwYWRkbGVFbGVtIiwicG9zaXRpb24iLCJwYXJzZUZsb2F0IiwiZ2V0Q29tcHV0ZWRTdHlsZSIsImdldFByb3BlcnR5VmFsdWUiLCJ2YWx1ZSIsInN0eWxlIiwic2V0UHJvcGVydHkiLCJ1cGRhdGUiLCJQbGF5ZXIySGVpZ2h0IiwiY3VzdG9tU3R5bGVzIiwib3ZlcmxheSIsImJhY2tncm91bmRDb2xvciIsImNvbnRlbnQiLCJ0b3AiLCJsZWZ0IiwicmlnaHQiLCJib3R0b20iLCJtYXJnaW5SaWdodCIsInRyYW5zZm9ybSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(ssr)/./src/app/game/Paddle.tsx\n");

/***/ }),

/***/ "(ssr)/./src/app/game/page.tsx":
/*!*******************************!*\
  !*** ./src/app/game/page.tsx ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Pong)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"(ssr)/./node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var socket_io_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! socket.io-client */ \"(ssr)/./node_modules/socket.io-client/build/esm-debug/index.js\");\n/* harmony import */ var react_modal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-modal */ \"(ssr)/./node_modules/react-modal/lib/index.js\");\n/* harmony import */ var react_modal__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_modal__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ \"(ssr)/./node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react.js\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _Ball__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Ball */ \"(ssr)/./src/app/game/Ball.tsx\");\n/* harmony import */ var _Paddle__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./Paddle */ \"(ssr)/./src/app/game/Paddle.tsx\");\n/* harmony import */ var _styles_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./styles.css */ \"(ssr)/./src/app/game/styles.css\");\n/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! next/navigation */ \"(ssr)/./node_modules/next/navigation.js\");\n/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_7__);\n/* __next_internal_client_entry_do_not_use__ default auto */ \n\n\n\n\n\n\n\n\nfunction Pong() {\n    let runGame = false, keepUpdating = false, isMeet = false;\n    const [message, setMessage] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(\"\");\n    const [isOpen, setIsOpen] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);\n    const router = (0,next_navigation__WEBPACK_IMPORTED_MODULE_7__.useSearchParams)();\n    const color = router.get(\"color\");\n    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{\n        if (runGame) {\n            // const socket = io(\"http://10.12.8.8:3001/\");\n            const socket = (0,socket_io_client__WEBPACK_IMPORTED_MODULE_1__.io)(\"http://localhost:3001\");\n            const ball = new _Ball__WEBPACK_IMPORTED_MODULE_4__[\"default\"](document.getElementById(\"ball\"));\n            const playerPaddle = new _Paddle__WEBPACK_IMPORTED_MODULE_5__[\"default\"](document.getElementById(\"player-paddle\"));\n            const Player2Paddle = new _Paddle__WEBPACK_IMPORTED_MODULE_5__[\"default\"](document.getElementById(\"bot-paddle\"));\n            const playerScoreElem = document.getElementById(\"player-score\");\n            const player2ScoreElem = document.getElementById(\"bot-score\");\n            let Player2Height = 50, ballY = 50, ballX = 50;\n            const hueColorChangeSet = color;\n            let ISadmin = false;\n            socket.connect();\n            socket.emit(\"join-room\");\n            socket.once(\"isAdmin\", (Admin)=>{\n                if (Admin.isAdmin === \"true\") {\n                    keepUpdating = true;\n                    ISadmin = true;\n                }\n            });\n            socket.once(\"meet-joined\", async ()=>{\n                if (ISadmin) {\n                    keepUpdating = false;\n                    isMeet = true;\n                    window.requestAnimationFrame(update);\n                } else {\n                    isMeet = true;\n                    update();\n                }\n            });\n            socket.on(\"Drawx\", (draw)=>{\n                ballX = draw.ballX;\n                ballY = draw.ballY;\n                if (ISadmin) {\n                    Player2Height = draw.playerYMeet;\n                    player2ScoreElem.textContent = draw.AdminScore;\n                    playerScoreElem.textContent = draw.MeetScore;\n                } else {\n                    Player2Height = draw.playerYAdmin;\n                    playerScoreElem.textContent = draw.AdminScore;\n                    player2ScoreElem.textContent = draw.MeetScore;\n                }\n            });\n            document.documentElement.style.setProperty(\"--hue\", hueColorChangeSet);\n            function update() {\n                if (!isMeet || keepUpdating || playerScoreElem.textContent === \"8\" || player2ScoreElem.textContent === \"8\") {\n                    ball.x = 50;\n                    ball.y = 50;\n                    if (playerScoreElem.textContent === \"8\" || player2ScoreElem.textContent === \"8\") {\n                        setMessage(\"End game\");\n                        // setIsOpen(true);\n                        socket.disconnect();\n                    }\n                    return;\n                }\n                Player2Paddle.update(Player2Height);\n                ball.update(ISadmin, ballX, ballY);\n                window.requestAnimationFrame(update);\n            }\n            document.addEventListener(\"mousemove\", (e)=>{\n                const pos = e.y / window.innerHeight * 100;\n                if (pos >= 92 || pos <= 8.5) return;\n                playerPaddle.position = pos;\n                if (ISadmin && isMeet) {\n                    socket.emit(\"coordinates_Admin\", {\n                        playerY: pos\n                    });\n                } else {\n                    socket.emit(\"coordinates_Meet\", {\n                        playerY: pos\n                    });\n                }\n            });\n        }\n        runGame = true;\n    }, []);\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n            className: \"gameContainer h-[250px] min-h-[1em] w-px self-stretch bg-gradient-to-tr from-transparent via-neutral-500 to-transparent\",\n            children: [\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                    className: \"score\",\n                    children: [\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                            className: \"player-score\",\n                            id: \"player-score\",\n                            children: \"0\"\n                        }, void 0, false, {\n                            fileName: \"/home/mhanda/Online-PoNg-Game/ping-pong/src/app/game/page.tsx\",\n                            lineNumber: 126,\n                            columnNumber: 11\n                        }, this),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                            className: \"bot-score\",\n                            id: \"bot-score\",\n                            children: \"0\"\n                        }, void 0, false, {\n                            fileName: \"/home/mhanda/Online-PoNg-Game/ping-pong/src/app/game/page.tsx\",\n                            lineNumber: 129,\n                            columnNumber: 11\n                        }, this)\n                    ]\n                }, void 0, true, {\n                    fileName: \"/home/mhanda/Online-PoNg-Game/ping-pong/src/app/game/page.tsx\",\n                    lineNumber: 125,\n                    columnNumber: 9\n                }, this),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                    className: \"ball\",\n                    id: \"ball\"\n                }, void 0, false, {\n                    fileName: \"/home/mhanda/Online-PoNg-Game/ping-pong/src/app/game/page.tsx\",\n                    lineNumber: 133,\n                    columnNumber: 9\n                }, this),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                    className: \"paddle left\",\n                    id: \"player-paddle\"\n                }, void 0, false, {\n                    fileName: \"/home/mhanda/Online-PoNg-Game/ping-pong/src/app/game/page.tsx\",\n                    lineNumber: 134,\n                    columnNumber: 9\n                }, this),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                    className: \"paddle right\",\n                    id: \"bot-paddle\"\n                }, void 0, false, {\n                    fileName: \"/home/mhanda/Online-PoNg-Game/ping-pong/src/app/game/page.tsx\",\n                    lineNumber: 135,\n                    columnNumber: 9\n                }, this),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                    className: \"middle_line\"\n                }, void 0, false, {\n                    fileName: \"/home/mhanda/Online-PoNg-Game/ping-pong/src/app/game/page.tsx\",\n                    lineNumber: 136,\n                    columnNumber: 9\n                }, this),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((react_modal__WEBPACK_IMPORTED_MODULE_2___default()), {\n                    isOpen: isOpen,\n                    onRequestClose: ()=>setIsOpen(false),\n                    style: _Paddle__WEBPACK_IMPORTED_MODULE_5__.customStyles,\n                    children: `${message}`\n                }, void 0, false, {\n                    fileName: \"/home/mhanda/Online-PoNg-Game/ping-pong/src/app/game/page.tsx\",\n                    lineNumber: 137,\n                    columnNumber: 9\n                }, this)\n            ]\n        }, void 0, true, {\n            fileName: \"/home/mhanda/Online-PoNg-Game/ping-pong/src/app/game/page.tsx\",\n            lineNumber: 120,\n            columnNumber: 7\n        }, this)\n    }, void 0, false);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHNzcikvLi9zcmMvYXBwL2dhbWUvcGFnZS50c3giLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDc0M7QUFDTjtBQUNZO0FBQ2xCO0FBQ0k7QUFDVTtBQUNsQjtBQUM0QjtBQUVuQyxTQUFTUTtJQUN0QixJQUFJQyxVQUFtQixPQUNyQkMsZUFBd0IsT0FDeEJDLFNBQWtCO0lBRXBCLE1BQU0sQ0FBQ0MsU0FBU0MsV0FBVyxHQUFHViwrQ0FBUUEsQ0FBQztJQUN2QyxNQUFNLENBQUNXLFFBQVFDLFVBQVUsR0FBR1osK0NBQVFBLENBQUM7SUFFckMsTUFBTWEsU0FBU1QsZ0VBQWVBO0lBQzlCLE1BQU1VLFFBQXVCRCxPQUFPRSxHQUFHLENBQUM7SUFFeENoQixnREFBU0EsQ0FBQztRQUNSLElBQUlPLFNBQVM7WUFDWCwrQ0FBK0M7WUFDL0MsTUFBTVUsU0FBU25CLG9EQUFFQSxDQUFDO1lBQ2xCLE1BQU1vQixPQUFPLElBQUloQiw2Q0FBSUEsQ0FBQ2lCLFNBQVNDLGNBQWMsQ0FBQztZQUM5QyxNQUFNQyxlQUFlLElBQUlsQiwrQ0FBTUEsQ0FBQ2dCLFNBQVNDLGNBQWMsQ0FBQztZQUN4RCxNQUFNRSxnQkFBZ0IsSUFBSW5CLCtDQUFNQSxDQUFDZ0IsU0FBU0MsY0FBYyxDQUFDO1lBQ3pELE1BQU1HLGtCQUNKSixTQUFTQyxjQUFjLENBQUM7WUFDMUIsTUFBTUksbUJBQ0pMLFNBQVNDLGNBQWMsQ0FBQztZQUMxQixJQUFJSyxnQkFBd0IsSUFDMUJDLFFBQWdCLElBQ2hCQyxRQUFnQjtZQUNsQixNQUFNQyxvQkFBbUNiO1lBQ3pDLElBQUljLFVBQW1CO1lBRXZCWixPQUFPYSxPQUFPO1lBQ2RiLE9BQU9jLElBQUksQ0FBQztZQUNaZCxPQUFPZSxJQUFJLENBQUMsV0FBVyxDQUFDQztnQkFDdEIsSUFBSUEsTUFBTUMsT0FBTyxLQUFLLFFBQVE7b0JBQzVCMUIsZUFBZTtvQkFDZnFCLFVBQVU7Z0JBQ1o7WUFDRjtZQUNBWixPQUFPZSxJQUFJLENBQUMsZUFBZTtnQkFDekIsSUFBSUgsU0FBUztvQkFDWHJCLGVBQWU7b0JBQ2ZDLFNBQVM7b0JBQ1QwQixPQUFPQyxxQkFBcUIsQ0FBQ0M7Z0JBQy9CLE9BQU87b0JBQ0w1QixTQUFTO29CQUNUNEI7Z0JBQ0Y7WUFDRjtZQUVBcEIsT0FBT3FCLEVBQUUsQ0FBQyxTQUFTLENBQUNDO2dCQUNsQlosUUFBUVksS0FBS1osS0FBSztnQkFDbEJELFFBQVFhLEtBQUtiLEtBQUs7Z0JBQ2xCLElBQUlHLFNBQVM7b0JBQ1hKLGdCQUFnQmMsS0FBS0MsV0FBVztvQkFDaENoQixpQkFBaUJpQixXQUFXLEdBQUdGLEtBQUtHLFVBQVU7b0JBQzlDbkIsZ0JBQWdCa0IsV0FBVyxHQUFHRixLQUFLSSxTQUFTO2dCQUM5QyxPQUFPO29CQUNMbEIsZ0JBQWdCYyxLQUFLSyxZQUFZO29CQUNqQ3JCLGdCQUFnQmtCLFdBQVcsR0FBR0YsS0FBS0csVUFBVTtvQkFDN0NsQixpQkFBaUJpQixXQUFXLEdBQUdGLEtBQUtJLFNBQVM7Z0JBQy9DO1lBQ0Y7WUFFQXhCLFNBQVMwQixlQUFlLENBQUNDLEtBQUssQ0FBQ0MsV0FBVyxDQUFDLFNBQVNuQjtZQUVwRCxTQUFTUztnQkFDUCxJQUNFLENBQUM1QixVQUNERCxnQkFDQWUsZ0JBQWdCa0IsV0FBVyxLQUFLLE9BQ2hDakIsaUJBQWlCaUIsV0FBVyxLQUFLLEtBQ2pDO29CQUNBdkIsS0FBSzhCLENBQUMsR0FBRztvQkFDVDlCLEtBQUsrQixDQUFDLEdBQUc7b0JBQ1QsSUFDRTFCLGdCQUFnQmtCLFdBQVcsS0FBSyxPQUNoQ2pCLGlCQUFpQmlCLFdBQVcsS0FBSyxLQUNqQzt3QkFDQTlCLFdBQVc7d0JBQ1gsbUJBQW1CO3dCQUNuQk0sT0FBT2lDLFVBQVU7b0JBQ25CO29CQUNBO2dCQUNGO2dCQUVBNUIsY0FBY2UsTUFBTSxDQUFDWjtnQkFFckJQLEtBQUttQixNQUFNLENBQUNSLFNBQVNGLE9BQU9EO2dCQUM1QlMsT0FBT0MscUJBQXFCLENBQUNDO1lBQy9CO1lBRUFsQixTQUFTZ0MsZ0JBQWdCLENBQUMsYUFBYSxDQUFDQztnQkFDdEMsTUFBTUMsTUFBTSxFQUFHSixDQUFDLEdBQUdkLE9BQU9tQixXQUFXLEdBQUk7Z0JBQ3pDLElBQUlELE9BQU8sTUFBTUEsT0FBTyxLQUFLO2dCQUM3QmhDLGFBQWFrQyxRQUFRLEdBQUdGO2dCQUN4QixJQUFJeEIsV0FBV3BCLFFBQVE7b0JBQ3JCUSxPQUFPYyxJQUFJLENBQUMscUJBQXFCO3dCQUMvQnlCLFNBQVNIO29CQUNYO2dCQUNGLE9BQU87b0JBQ0xwQyxPQUFPYyxJQUFJLENBQUMsb0JBQW9CO3dCQUM5QnlCLFNBQVNIO29CQUNYO2dCQUNGO1lBQ0Y7UUFDRjtRQUNBOUMsVUFBVTtJQUNaLEdBQUcsRUFBRTtJQUVMLHFCQUNFO2tCQUNFLDRFQUFDa0Q7WUFDQ0MsV0FBVTs7OEJBSVYsOERBQUNEO29CQUFJQyxXQUFVOztzQ0FDYiw4REFBQ0Q7NEJBQUlDLFdBQVU7NEJBQWVDLElBQUc7c0NBQWU7Ozs7OztzQ0FHaEQsOERBQUNGOzRCQUFJQyxXQUFVOzRCQUFZQyxJQUFHO3NDQUFZOzs7Ozs7Ozs7Ozs7OEJBSTVDLDhEQUFDRjtvQkFBSUMsV0FBVTtvQkFBT0MsSUFBRzs7Ozs7OzhCQUN6Qiw4REFBQ0Y7b0JBQUlDLFdBQVU7b0JBQWNDLElBQUc7Ozs7Ozs4QkFDaEMsOERBQUNGO29CQUFJQyxXQUFVO29CQUFlQyxJQUFHOzs7Ozs7OEJBQ2pDLDhEQUFDRjtvQkFBSUMsV0FBVTs7Ozs7OzhCQUNmLDhEQUFDM0Qsb0RBQUtBO29CQUNKYSxRQUFRQTtvQkFDUmdELGdCQUFnQixJQUFNL0MsVUFBVTtvQkFDaENpQyxPQUFPMUMsaURBQVlBOzhCQUVsQixDQUFDLEVBQUVNLFFBQVEsQ0FBQzs7Ozs7Ozs7Ozs7OztBQUt2QiIsInNvdXJjZXMiOlsid2VicGFjazovL3BpbmctcG9uZy8uL3NyYy9hcHAvZ2FtZS9wYWdlLnRzeD84Yjk3Il0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgaW8gfSBmcm9tIFwic29ja2V0LmlvLWNsaWVudFwiO1xuaW1wb3J0IE1vZGFsIGZyb20gXCJyZWFjdC1tb2RhbFwiO1xuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IEJhbGwgZnJvbSBcIi4vQmFsbFwiO1xuaW1wb3J0IFBhZGRsZSBmcm9tIFwiLi9QYWRkbGVcIjtcbmltcG9ydCB7IGN1c3RvbVN0eWxlcyB9IGZyb20gXCIuL1BhZGRsZVwiO1xuaW1wb3J0IFwiLi9zdHlsZXMuY3NzXCI7XG5pbXBvcnQgeyB1c2VTZWFyY2hQYXJhbXMgfSBmcm9tIFwibmV4dC9uYXZpZ2F0aW9uXCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFBvbmcoKSB7XG4gIGxldCBydW5HYW1lOiBib29sZWFuID0gZmFsc2UsXG4gICAga2VlcFVwZGF0aW5nOiBib29sZWFuID0gZmFsc2UsXG4gICAgaXNNZWV0OiBib29sZWFuID0gZmFsc2U7XG5cbiAgY29uc3QgW21lc3NhZ2UsIHNldE1lc3NhZ2VdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtpc09wZW4sIHNldElzT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgY29uc3Qgcm91dGVyID0gdXNlU2VhcmNoUGFyYW1zKCk7XG4gIGNvbnN0IGNvbG9yOiBzdHJpbmcgfCBudWxsID0gcm91dGVyLmdldChcImNvbG9yXCIpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKHJ1bkdhbWUpIHtcbiAgICAgIC8vIGNvbnN0IHNvY2tldCA9IGlvKFwiaHR0cDovLzEwLjEyLjguODozMDAxL1wiKTtcbiAgICAgIGNvbnN0IHNvY2tldCA9IGlvKFwiaHR0cDovL2xvY2FsaG9zdDozMDAxXCIpO1xuICAgICAgY29uc3QgYmFsbCA9IG5ldyBCYWxsKGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiYmFsbFwiKSk7XG4gICAgICBjb25zdCBwbGF5ZXJQYWRkbGUgPSBuZXcgUGFkZGxlKGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwicGxheWVyLXBhZGRsZVwiKSk7XG4gICAgICBjb25zdCBQbGF5ZXIyUGFkZGxlID0gbmV3IFBhZGRsZShkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImJvdC1wYWRkbGVcIikpO1xuICAgICAgY29uc3QgcGxheWVyU2NvcmVFbGVtOiBIVE1MRWxlbWVudCB8IG51bGwgPVxuICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInBsYXllci1zY29yZVwiKTtcbiAgICAgIGNvbnN0IHBsYXllcjJTY29yZUVsZW06IEhUTUxFbGVtZW50IHwgbnVsbCA9XG4gICAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiYm90LXNjb3JlXCIpO1xuICAgICAgbGV0IFBsYXllcjJIZWlnaHQ6IG51bWJlciA9IDUwLFxuICAgICAgICBiYWxsWTogbnVtYmVyID0gNTAsXG4gICAgICAgIGJhbGxYOiBudW1iZXIgPSA1MDtcbiAgICAgIGNvbnN0IGh1ZUNvbG9yQ2hhbmdlU2V0OiBzdHJpbmcgfCBudWxsID0gY29sb3I7XG4gICAgICBsZXQgSVNhZG1pbjogYm9vbGVhbiA9IGZhbHNlO1xuXG4gICAgICBzb2NrZXQuY29ubmVjdCgpO1xuICAgICAgc29ja2V0LmVtaXQoXCJqb2luLXJvb21cIik7XG4gICAgICBzb2NrZXQub25jZShcImlzQWRtaW5cIiwgKEFkbWluKSA9PiB7XG4gICAgICAgIGlmIChBZG1pbi5pc0FkbWluID09PSBcInRydWVcIikge1xuICAgICAgICAgIGtlZXBVcGRhdGluZyA9IHRydWU7XG4gICAgICAgICAgSVNhZG1pbiA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgc29ja2V0Lm9uY2UoXCJtZWV0LWpvaW5lZFwiLCBhc3luYyAoKSA9PiB7XG4gICAgICAgIGlmIChJU2FkbWluKSB7XG4gICAgICAgICAga2VlcFVwZGF0aW5nID0gZmFsc2U7XG4gICAgICAgICAgaXNNZWV0ID0gdHJ1ZTtcbiAgICAgICAgICB3aW5kb3cucmVxdWVzdEFuaW1hdGlvbkZyYW1lKHVwZGF0ZSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgaXNNZWV0ID0gdHJ1ZTtcbiAgICAgICAgICB1cGRhdGUoKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG5cbiAgICAgIHNvY2tldC5vbihcIkRyYXd4XCIsIChkcmF3KSA9PiB7XG4gICAgICAgIGJhbGxYID0gZHJhdy5iYWxsWDtcbiAgICAgICAgYmFsbFkgPSBkcmF3LmJhbGxZO1xuICAgICAgICBpZiAoSVNhZG1pbikge1xuICAgICAgICAgIFBsYXllcjJIZWlnaHQgPSBkcmF3LnBsYXllcllNZWV0O1xuICAgICAgICAgIHBsYXllcjJTY29yZUVsZW0udGV4dENvbnRlbnQgPSBkcmF3LkFkbWluU2NvcmU7XG4gICAgICAgICAgcGxheWVyU2NvcmVFbGVtLnRleHRDb250ZW50ID0gZHJhdy5NZWV0U2NvcmU7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgUGxheWVyMkhlaWdodCA9IGRyYXcucGxheWVyWUFkbWluO1xuICAgICAgICAgIHBsYXllclNjb3JlRWxlbS50ZXh0Q29udGVudCA9IGRyYXcuQWRtaW5TY29yZTtcbiAgICAgICAgICBwbGF5ZXIyU2NvcmVFbGVtLnRleHRDb250ZW50ID0gZHJhdy5NZWV0U2NvcmU7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuXG4gICAgICBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuc3R5bGUuc2V0UHJvcGVydHkoXCItLWh1ZVwiLCBodWVDb2xvckNoYW5nZVNldCk7XG5cbiAgICAgIGZ1bmN0aW9uIHVwZGF0ZSgpIHtcbiAgICAgICAgaWYgKFxuICAgICAgICAgICFpc01lZXQgfHxcbiAgICAgICAgICBrZWVwVXBkYXRpbmcgfHxcbiAgICAgICAgICBwbGF5ZXJTY29yZUVsZW0udGV4dENvbnRlbnQgPT09IFwiOFwiIHx8XG4gICAgICAgICAgcGxheWVyMlNjb3JlRWxlbS50ZXh0Q29udGVudCA9PT0gXCI4XCJcbiAgICAgICAgKSB7XG4gICAgICAgICAgYmFsbC54ID0gNTA7XG4gICAgICAgICAgYmFsbC55ID0gNTA7XG4gICAgICAgICAgaWYgKFxuICAgICAgICAgICAgcGxheWVyU2NvcmVFbGVtLnRleHRDb250ZW50ID09PSBcIjhcIiB8fFxuICAgICAgICAgICAgcGxheWVyMlNjb3JlRWxlbS50ZXh0Q29udGVudCA9PT0gXCI4XCJcbiAgICAgICAgICApIHtcbiAgICAgICAgICAgIHNldE1lc3NhZ2UoXCJFbmQgZ2FtZVwiKTtcbiAgICAgICAgICAgIC8vIHNldElzT3Blbih0cnVlKTtcbiAgICAgICAgICAgIHNvY2tldC5kaXNjb25uZWN0KCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIFBsYXllcjJQYWRkbGUudXBkYXRlKFBsYXllcjJIZWlnaHQpO1xuXG4gICAgICAgIGJhbGwudXBkYXRlKElTYWRtaW4sIGJhbGxYLCBiYWxsWSk7XG4gICAgICAgIHdpbmRvdy5yZXF1ZXN0QW5pbWF0aW9uRnJhbWUodXBkYXRlKTtcbiAgICAgIH1cblxuICAgICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcIm1vdXNlbW92ZVwiLCAoZSkgPT4ge1xuICAgICAgICBjb25zdCBwb3MgPSAoZS55IC8gd2luZG93LmlubmVySGVpZ2h0KSAqIDEwMDtcbiAgICAgICAgaWYgKHBvcyA+PSA5MiB8fCBwb3MgPD0gOC41KSByZXR1cm47XG4gICAgICAgIHBsYXllclBhZGRsZS5wb3NpdGlvbiA9IHBvcztcbiAgICAgICAgaWYgKElTYWRtaW4gJiYgaXNNZWV0KSB7XG4gICAgICAgICAgc29ja2V0LmVtaXQoXCJjb29yZGluYXRlc19BZG1pblwiLCB7XG4gICAgICAgICAgICBwbGF5ZXJZOiBwb3MsXG4gICAgICAgICAgfSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgc29ja2V0LmVtaXQoXCJjb29yZGluYXRlc19NZWV0XCIsIHtcbiAgICAgICAgICAgIHBsYXllclk6IHBvcyxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICAgIHJ1bkdhbWUgPSB0cnVlO1xuICB9LCBbXSk7XG5cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPGRpdlxuICAgICAgICBjbGFzc05hbWU9XCJnYW1lQ29udGFpbmVyIGgtWzI1MHB4XSBtaW4taC1bMWVtXSB3LXB4IHNlbGYtc3RyZXRjaFxuICAgICAgICBiZy1ncmFkaWVudC10by10ciBmcm9tLXRyYW5zcGFyZW50IHZpYS1uZXV0cmFsLTUwMFxuICAgICAgICB0by10cmFuc3BhcmVudFwiXG4gICAgICA+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2NvcmVcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBsYXllci1zY29yZVwiIGlkPVwicGxheWVyLXNjb3JlXCI+XG4gICAgICAgICAgICAwXG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3Qtc2NvcmVcIiBpZD1cImJvdC1zY29yZVwiPlxuICAgICAgICAgICAgMFxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiYWxsXCIgaWQ9XCJiYWxsXCI+PC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGFkZGxlIGxlZnRcIiBpZD1cInBsYXllci1wYWRkbGVcIj48L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYWRkbGUgcmlnaHRcIiBpZD1cImJvdC1wYWRkbGVcIj48L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaWRkbGVfbGluZVwiPjwvZGl2PlxuICAgICAgICA8TW9kYWxcbiAgICAgICAgICBpc09wZW49e2lzT3Blbn1cbiAgICAgICAgICBvblJlcXVlc3RDbG9zZT17KCkgPT4gc2V0SXNPcGVuKGZhbHNlKX1cbiAgICAgICAgICBzdHlsZT17Y3VzdG9tU3R5bGVzfVxuICAgICAgICA+XG4gICAgICAgICAge2Ake21lc3NhZ2V9YH1cbiAgICAgICAgPC9Nb2RhbD5cbiAgICAgIDwvZGl2PlxuICAgIDwvPlxuICApO1xufVxuIl0sIm5hbWVzIjpbImlvIiwiTW9kYWwiLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIkJhbGwiLCJQYWRkbGUiLCJjdXN0b21TdHlsZXMiLCJ1c2VTZWFyY2hQYXJhbXMiLCJQb25nIiwicnVuR2FtZSIsImtlZXBVcGRhdGluZyIsImlzTWVldCIsIm1lc3NhZ2UiLCJzZXRNZXNzYWdlIiwiaXNPcGVuIiwic2V0SXNPcGVuIiwicm91dGVyIiwiY29sb3IiLCJnZXQiLCJzb2NrZXQiLCJiYWxsIiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsInBsYXllclBhZGRsZSIsIlBsYXllcjJQYWRkbGUiLCJwbGF5ZXJTY29yZUVsZW0iLCJwbGF5ZXIyU2NvcmVFbGVtIiwiUGxheWVyMkhlaWdodCIsImJhbGxZIiwiYmFsbFgiLCJodWVDb2xvckNoYW5nZVNldCIsIklTYWRtaW4iLCJjb25uZWN0IiwiZW1pdCIsIm9uY2UiLCJBZG1pbiIsImlzQWRtaW4iLCJ3aW5kb3ciLCJyZXF1ZXN0QW5pbWF0aW9uRnJhbWUiLCJ1cGRhdGUiLCJvbiIsImRyYXciLCJwbGF5ZXJZTWVldCIsInRleHRDb250ZW50IiwiQWRtaW5TY29yZSIsIk1lZXRTY29yZSIsInBsYXllcllBZG1pbiIsImRvY3VtZW50RWxlbWVudCIsInN0eWxlIiwic2V0UHJvcGVydHkiLCJ4IiwieSIsImRpc2Nvbm5lY3QiLCJhZGRFdmVudExpc3RlbmVyIiwiZSIsInBvcyIsImlubmVySGVpZ2h0IiwicG9zaXRpb24iLCJwbGF5ZXJZIiwiZGl2IiwiY2xhc3NOYW1lIiwiaWQiLCJvblJlcXVlc3RDbG9zZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(ssr)/./src/app/game/page.tsx\n");

/***/ }),

/***/ "(ssr)/./src/app/game/styles.css":
/*!*********************************!*\
  !*** ./src/app/game/styles.css ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (\"7f80e6c24587\");\nif (false) {}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHNzcikvLi9zcmMvYXBwL2dhbWUvc3R5bGVzLmNzcyIsIm1hcHBpbmdzIjoiOzs7O0FBQUEsaUVBQWUsY0FBYztBQUM3QixJQUFJLEtBQVUsRUFBRSxFQUF1QiIsInNvdXJjZXMiOlsid2VicGFjazovL3BpbmctcG9uZy8uL3NyYy9hcHAvZ2FtZS9zdHlsZXMuY3NzP2Y5NTAiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGRlZmF1bHQgXCI3ZjgwZTZjMjQ1ODdcIlxuaWYgKG1vZHVsZS5ob3QpIHsgbW9kdWxlLmhvdC5hY2NlcHQoKSB9XG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(ssr)/./src/app/game/styles.css\n");

/***/ }),

/***/ "(rsc)/./src/app/globals.css":
/*!*****************************!*\
  !*** ./src/app/globals.css ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (\"2d05991c511e\");\nif (false) {}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9zcmMvYXBwL2dsb2JhbHMuY3NzIiwibWFwcGluZ3MiOiI7Ozs7QUFBQSxpRUFBZSxjQUFjO0FBQzdCLElBQUksS0FBVSxFQUFFLEVBQXVCIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vcGluZy1wb25nLy4vc3JjL2FwcC9nbG9iYWxzLmNzcz9kYTJlIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBkZWZhdWx0IFwiMmQwNTk5MWM1MTFlXCJcbmlmIChtb2R1bGUuaG90KSB7IG1vZHVsZS5ob3QuYWNjZXB0KCkgfVxuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(rsc)/./src/app/globals.css\n");

/***/ }),

/***/ "(rsc)/./src/app/game/page.tsx":
/*!*******************************!*\
  !*** ./src/app/game/page.tsx ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/build/webpack/loaders/next-flight-loader/module-proxy */ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js");

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/home/mhanda/Online-PoNg-Game/ping-pong/src/app/game/page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ "(rsc)/./src/app/layout.tsx":
/*!****************************!*\
  !*** ./src/app/layout.tsx ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ RootLayout),\n/* harmony export */   metadata: () => (/* binding */ metadata)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"(rsc)/./node_modules/next/dist/server/future/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_font_google_target_css_path_src_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/font/google/target.css?{\"path\":\"src/app/layout.tsx\",\"import\":\"Inter\",\"arguments\":[{\"subsets\":[\"latin\"]}],\"variableName\":\"inter\"} */ \"(rsc)/./node_modules/next/font/google/target.css?{\\\"path\\\":\\\"src/app/layout.tsx\\\",\\\"import\\\":\\\"Inter\\\",\\\"arguments\\\":[{\\\"subsets\\\":[\\\"latin\\\"]}],\\\"variableName\\\":\\\"inter\\\"}\");\n/* harmony import */ var next_font_google_target_css_path_src_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_font_google_target_css_path_src_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./globals.css */ \"(rsc)/./src/app/globals.css\");\n\n\n\nconst metadata = {\n    title: \"Create Next App\",\n    description: \"Generated by create next app\"\n};\nfunction RootLayout({ children }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"html\", {\n        lang: \"en\",\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"body\", {\n            className: (next_font_google_target_css_path_src_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_2___default().className),\n            children: children\n        }, void 0, false, {\n            fileName: \"/home/mhanda/Online-PoNg-Game/ping-pong/src/app/layout.tsx\",\n            lineNumber: 15,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"/home/mhanda/Online-PoNg-Game/ping-pong/src/app/layout.tsx\",\n        lineNumber: 14,\n        columnNumber: 5\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9zcmMvYXBwL2xheW91dC50c3giLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFJTUE7QUFKaUI7QUFNaEIsTUFBTUMsV0FBcUI7SUFDaENDLE9BQU87SUFDUEMsYUFBYTtBQUNmLEVBQUU7QUFFYSxTQUFTQyxXQUFXLEVBQUVDLFFBQVEsRUFBbUM7SUFDOUUscUJBQ0UsOERBQUNDO1FBQUtDLE1BQUs7a0JBQ1QsNEVBQUNDO1lBQUtDLFdBQVdULCtKQUFlO3NCQUFHSzs7Ozs7Ozs7Ozs7QUFHekMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9waW5nLXBvbmcvLi9zcmMvYXBwL2xheW91dC50c3g/NTdhOSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgXCIuL2dsb2JhbHMuY3NzXCI7XG5pbXBvcnQgdHlwZSB7IE1ldGFkYXRhIH0gZnJvbSBcIm5leHRcIjtcbmltcG9ydCB7IEludGVyIH0gZnJvbSBcIm5leHQvZm9udC9nb29nbGVcIjtcblxuY29uc3QgaW50ZXIgPSBJbnRlcih7IHN1YnNldHM6IFtcImxhdGluXCJdIH0pO1xuXG5leHBvcnQgY29uc3QgbWV0YWRhdGE6IE1ldGFkYXRhID0ge1xuICB0aXRsZTogXCJDcmVhdGUgTmV4dCBBcHBcIixcbiAgZGVzY3JpcHRpb246IFwiR2VuZXJhdGVkIGJ5IGNyZWF0ZSBuZXh0IGFwcFwiLFxufTtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUm9vdExheW91dCh7IGNoaWxkcmVuLCB9OiB7IGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGU7IH0pIHtcbiAgcmV0dXJuIChcbiAgICA8aHRtbCBsYW5nPVwiZW5cIj5cbiAgICAgIDxib2R5IGNsYXNzTmFtZT17aW50ZXIuY2xhc3NOYW1lfT57Y2hpbGRyZW59PC9ib2R5PlxuICAgIDwvaHRtbD5cbiAgKTtcbn1cbiJdLCJuYW1lcyI6WyJpbnRlciIsIm1ldGFkYXRhIiwidGl0bGUiLCJkZXNjcmlwdGlvbiIsIlJvb3RMYXlvdXQiLCJjaGlsZHJlbiIsImh0bWwiLCJsYW5nIiwiYm9keSIsImNsYXNzTmFtZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(rsc)/./src/app/layout.tsx\n");

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-metadata-image-loader.js?type=favicon&segment=&basePath=&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js!./src/app/favicon.ico?__next_metadata__":
/*!**************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-metadata-image-loader.js?type=favicon&segment=&basePath=&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js!./src/app/favicon.ico?__next_metadata__ ***!
  \**************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/lib/metadata/get-metadata-route */ \"(rsc)/./node_modules/next/dist/lib/metadata/get-metadata-route.js\");\n/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__);\n  \n\n  /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props) => {\n    const imageData = {\"type\":\"image/x-icon\",\"sizes\":\"16x16\"}\n    const imageUrl = (0,next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__.fillMetadataSegment)(\".\", props.params, \"favicon.ico\")\n\n    return [{\n      ...imageData,\n      url: imageUrl + \"\",\n    }]\n  });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LW1ldGFkYXRhLWltYWdlLWxvYWRlci5qcz90eXBlPWZhdmljb24mc2VnbWVudD0mYmFzZVBhdGg9JnBhZ2VFeHRlbnNpb25zPXRzeCZwYWdlRXh0ZW5zaW9ucz10cyZwYWdlRXh0ZW5zaW9ucz1qc3gmcGFnZUV4dGVuc2lvbnM9anMhLi9zcmMvYXBwL2Zhdmljb24uaWNvP19fbmV4dF9tZXRhZGF0YV9fIiwibWFwcGluZ3MiOiI7Ozs7OztBQUFBLEVBQWlGOztBQUVqRixFQUFFLGlFQUFlO0FBQ2pCLHVCQUF1QjtBQUN2QixxQkFBcUIsOEZBQW1COztBQUV4QztBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9waW5nLXBvbmcvLi9zcmMvYXBwL2Zhdmljb24uaWNvP2ZiMTMiXSwic291cmNlc0NvbnRlbnQiOlsiICBpbXBvcnQgeyBmaWxsTWV0YWRhdGFTZWdtZW50IH0gZnJvbSAnbmV4dC9kaXN0L2xpYi9tZXRhZGF0YS9nZXQtbWV0YWRhdGEtcm91dGUnXG5cbiAgZXhwb3J0IGRlZmF1bHQgKHByb3BzKSA9PiB7XG4gICAgY29uc3QgaW1hZ2VEYXRhID0ge1widHlwZVwiOlwiaW1hZ2UveC1pY29uXCIsXCJzaXplc1wiOlwiMTZ4MTZcIn1cbiAgICBjb25zdCBpbWFnZVVybCA9IGZpbGxNZXRhZGF0YVNlZ21lbnQoXCIuXCIsIHByb3BzLnBhcmFtcywgXCJmYXZpY29uLmljb1wiKVxuXG4gICAgcmV0dXJuIFt7XG4gICAgICAuLi5pbWFnZURhdGEsXG4gICAgICB1cmw6IGltYWdlVXJsICsgXCJcIixcbiAgICB9XVxuICB9Il0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(rsc)/./node_modules/next/dist/build/webpack/loaders/next-metadata-image-loader.js?type=favicon&segment=&basePath=&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js!./src/app/favicon.ico?__next_metadata__\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/@swc","vendor-chunks/engine.io-client","vendor-chunks/ws","vendor-chunks/react-modal","vendor-chunks/socket.io-client","vendor-chunks/prop-types","vendor-chunks/engine.io-parser","vendor-chunks/debug","vendor-chunks/socket.io-parser","vendor-chunks/react-is","vendor-chunks/@socket.io","vendor-chunks/xmlhttprequest-ssl","vendor-chunks/warning","vendor-chunks/supports-color","vendor-chunks/react-lifecycles-compat","vendor-chunks/object-assign","vendor-chunks/ms","vendor-chunks/has-flag","vendor-chunks/exenv"], () => (__webpack_exec__("(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fgame%2Fpage&page=%2Fgame%2Fpage&appPaths=%2Fgame%2Fpage&pagePath=private-next-app-dir%2Fgame%2Fpage.tsx&appDir=%2Fhome%2Fmhanda%2FOnline-PoNg-Game%2Fping-pong%2Fsrc%2Fapp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=%2Fhome%2Fmhanda%2FOnline-PoNg-Game%2Fping-pong&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!")));
module.exports = __webpack_exports__;

})();